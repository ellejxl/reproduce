library(testthat)
library(scAnnotate)

test_check("scAnnotate")
